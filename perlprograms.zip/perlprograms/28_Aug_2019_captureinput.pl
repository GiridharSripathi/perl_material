
print "Enter your name :";
$name = <STDIN>;

# chomp will remove the trailing newline characters
chomp($name);

print "Your name is : $name \n";

print STDOUT "this is using stdout handler\n";