use strict;
use warnings;

my @list;
my $lastelement;

# array functions
@list = ("perl","python");
push(@list,"java");
print "After push : @list \n";
push(@list,"oracle");
print "After push : @list \n";
push(@list, "scala", "hadoop", "spark");
print "After push : @list \n";
$lastelement = pop(@list);
print "Removed element is : $lastelement \n";
$lastelement = pop(@list);
print "Removed element is : $lastelement \n";
$lastelement = pop(@list);
print "Removed element is : $lastelement \n";

unshift(@list,"db2");
print "After unshift operation : @list \n";
unshift(@list,"ruby","go");
print "After unshift operation : @list \n";

shift(@list);
shift(@list);
shift(@list);
shift(@list);
print "After shift operation : @list \n";
