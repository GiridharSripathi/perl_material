

$name = "perl programming";

print "$name\n";

print "$name is used for infra automations\n";	

