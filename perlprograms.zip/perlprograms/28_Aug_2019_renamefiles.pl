use POSIX qw(strftime) ;
opendir(DIR , "."  ) or die("unable to open the directory : $! ");

$timestamp = strftime "%d_%b_%Y_", localtime;
print $timestamp;

while ( $file = readdir(DIR) )
{
	if (-f $file )
	{
		@out = split(/\./ , $file ) ;
		if ( $out[1] eq "pl" )
		{
			$newfile = $timestamp.$file;
			print $newfile , "\n";
			rename($file,$newfile) or warn('unable to rename');
			
		}
	}
}
