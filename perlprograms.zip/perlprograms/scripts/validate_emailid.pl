#!/usr/bin/perl
use strict;
use warnings;

use Email::Valid;

my $email_address = 'a.n@example.com';

if ( Email::Valid->address($email_address) ) 
{
	print "Its valid mail id\n";    
}
else
{
	print "Sorry, that email address is not valid!";
}