
$first = "python";
$second = "programming";

$output = $first.$second;

print "Output : $output\n";


print $first x 10 ;