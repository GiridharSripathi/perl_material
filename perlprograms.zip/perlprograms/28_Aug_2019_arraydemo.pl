@info = (10,20,30,45,50);

print "@info\n";

print "First element : $info[0] \n";

print "second element : $info[1] \n";

print "third element : $info[2] \n";

# last value
print "last element : $info[-1] \n";
# second last value
print " last but one element : $info[-2] \n";

print "few elements : @info[1,2] \n";
print "Last index :", $#info ;
print "\n";
# length of array
print "Length of the array :", $#info + 1 , "\n";



