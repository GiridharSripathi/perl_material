

$a = 10 ;
$b = 20 ;

if ( $a < $b )
{
	print "$a is less than $b\n";
}
else
{
	print "$a is greater than $b\n";
}