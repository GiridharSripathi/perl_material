
# displaying line by line
sub add
{
	foreach $value ( @_ )
	{
		print $value;
	}
}


add(1,2);