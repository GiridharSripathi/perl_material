#display files and directories seperately
opendir(DIR , "."  ) or die("unable to open the directory : $! ");

@files = ();
@dirs = ();
while ( $file = readdir(DIR) )
{
	if (-f $file )
	{
		push( @files , $file );
	}
	else
	{
		push ( @dirs, $file) ;
	}
}

# display files
foreach $file ( @files )
{
	print "$file\n";
}

print "-------------------------\n";
# display files
foreach $file ( @dirs)
{
	print "$file\n";
}


