

# delete the files

$path = "C:\\Users\\Admin\\Desktop\\backupfiles\\";
chdir($path) ;
opendir(DIR , $path  ) or die("unable to open the directory : $! ");

while ( $file = readdir(DIR) )
{
	if ( -f $file )
	{
		@out = 	split(/\./ , $file );
		if ($out[1] eq "pl") 
		{
			unlink($file) and print("$file deleted\n");
		}

	}
}

closedir(DIR) ;
