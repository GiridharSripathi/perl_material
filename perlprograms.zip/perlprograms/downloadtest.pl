
# downloading
use strict;
use warnings;
use LWP::Simple;

my $url = 'http://strawberryperl.com/download/5.30.0.1/strawberry-perl-5.30.0.1-64bit.msi';
my @data = split('/',$url) ;

my $file = $data[-1];

getstore($url, $file);

#####################################################################################
use strict;
use warnings;

use LWP::Simple;

my $url = 'http://samplecsvs.s3.amazonaws.com/Sacramentorealestatetransactions.csv';

my @data = split('/',$url) ;

my $filename = $data[-1];

getstore($url, $filename);