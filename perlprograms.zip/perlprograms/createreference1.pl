#creating reference
@arr1 = (10,20);

print "@arr1\n";

# creating reference
$refarr1 = \@arr1;

print "first reference : $refarr1\n";

#derefererce
print "First array : @$refarr1 \n";
