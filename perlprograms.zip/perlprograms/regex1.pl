#   =~ is called as binding operator

open(READ, "languages1.txt");

while ( $line = <READ> )
{	
	if ( $line =~ m/perl/ )
	{
		print $line;
	}
}

close(READ);

