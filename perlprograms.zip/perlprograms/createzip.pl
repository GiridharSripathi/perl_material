# Create a Zip file
use Archive::Zip qw( :ERROR_CODES :CONSTANTS );
my $zip = Archive::Zip->new();
my $file_member;


$path = 'C:\Users\Admin\Desktop';

$source = 'C:\Users\Admin\Desktop\perlprograms';

opendir(DIR , $source);

while ( $file = readdir(DIR) )
{
	#print "$file\n";
	$file_member = $zip->addFile($file); 
	my $member = $zip->memberNamed($file );
	$member->desiredCompressionMethod( COMPRESSION_STORED );

}

# Save the Zip file
unless ( $zip->writeToFileNamed('someZip.zip') == AZ_OK ) {
    die 'write error';
}

closedir(DIR);
