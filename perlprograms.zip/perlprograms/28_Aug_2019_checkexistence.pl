
$password = 'abc#';

@info = split('',$password);

print "@info";
