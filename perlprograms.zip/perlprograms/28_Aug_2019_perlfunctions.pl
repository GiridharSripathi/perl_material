

# scalar functions

$name = "python programming ";

chomp($name);

$lastchar = chop($name);
print "last character : $lastchar \n";
$lastchar = chop($name);
print "last character : $lastchar \n";
$lastchar = chop($name);
print "last character : $lastchar \n";
$name = "python";
print "String : $name \n";
print "Upper :", uc($name) , "\n";
print "lower :", lc($name) , "\n";
print "Upper first :" , ucfirst($name) , "\n";
print "Lower first :" , lcfirst($name) , "\n";

print  "Length of the string : ", length($name) , "\n";
$rev = reverse($name);
print "Reverse the string :", $rev , "\n";



