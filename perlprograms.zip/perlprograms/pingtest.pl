
use Net::Ping;


my $host = "facebook1234afdsfafa.com";


# Create a new ping object
$p = Net::Ping->new("tcp");

$p->port_number("80");

# perform the ping
if( $p->ping($host) )
{
        print "Host ".$host." is alive\n";
}
else
{
        print "Host ".$host." is dead\n";
}
$p->close();