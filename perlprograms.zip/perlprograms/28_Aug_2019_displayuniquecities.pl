
open( READ, "realestate.csv"); 
%unique = ();
while ( $line = <READ> )
{
	chomp $line ;
	@output = split("," , $line) ;
	$city =  $output[1];
	$unique{$city} = 1 ;

}

foreach $city ( keys %unique )
{
	print $city , "\n" ;
}