
# displaying files from the C:

$path = "C:\\";
opendir(DIR , $path  ) or die("unable to open the directory : $! ");

while ( $file = readdir(DIR) )
{
	if ( -d $path.$file )
	{
		print "$file\n";
	}
}

closedir(DIR) ;
