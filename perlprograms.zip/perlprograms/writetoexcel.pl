use Excel::Writer::XLSX;                                   # Step 0
 


open ( READ, "realestate.csv");
my $workbook = Excel::Writer::XLSX->new( 'perl.xlsx' );    # Step 1
$worksheet = $workbook->add_worksheet();                   # Step 2
$row = 0 ;
while ( $line = <READ> )
{	
	
	@output = split("," , $line );
	print "@output\n";
	$len = scalar(@output);
	#print "$len\n";
	
	foreach $column ( 0 .. $len ) 
	{
		$worksheet->write( $row, $column, $output[$column]);
 	}
	$row = $row + 1;
}
$workbook->close();
close(READ);