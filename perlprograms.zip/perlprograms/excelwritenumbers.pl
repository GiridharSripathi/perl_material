use Excel::Writer::XLSX;
use strict;
use warnings;

my $value ;
my $workbook  = Excel::Writer::XLSX->new( 'filename.xlsx' );
my $worksheet = $workbook->add_worksheet();

foreach $value ( 1..10)
{
	$worksheet->write( $value, 0, $value );
}
$workbook->close();