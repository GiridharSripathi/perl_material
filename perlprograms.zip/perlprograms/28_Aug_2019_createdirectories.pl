

foreach $val ( 1..10)
{
	$dir = 'dir'.'.'.$val;
	rmdir($dir);
}