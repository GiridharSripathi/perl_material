=start
print "hash functions\n";
=cut

%book = ("chap1", 10 , "chap2",20);
# adding new key-value pair to the hash
$book{"chap3"} = 30 ;
$,=  ' ';
print "After adding new key-valur pair : " , %book  , "\n";

@onlykeys = keys(%book) ;
@onlyvalues =  values(%book) ;

print "Only keys : @onlykeys \n";
print "Only values: @onlyvalues \n";

# delete key-valur pair
delete($book{'chap1'});
print "After deleting : ", %book , "\n";