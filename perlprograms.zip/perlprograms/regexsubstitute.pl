$line = "I love perl programming in perlword";
$line =~ s/perl/python/;
print "After substitution : $line\n";


# replace globally
$line = "I love perl programming in perl perlword";
$line =~ s/perl/python/g;
print "After substitution : $line\n";


# i =  ignore the case
$line = "I love PERL programming in perlword";
$line =~ s/perl/python/gi;
print "After substitution : $line\n";

################# translation happens for the corresponding characters ########################
$name = "python";
$name =~ tr/a-z/A-Z/;
print "After translating : $name\n";

$name = "python";      # y ---> Y    h  --->h 
$name =~ tr/ph/AZ/;
print "After translating : $name\n";



