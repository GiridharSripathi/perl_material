

# split()
$line = 'perl,unix,hadoop,scala';
@output = split("," , $line ) ;
print "After split operation : @output \n";


# join()
@list = (1,2,3,4,5);
$single =  join("-", @list) ;
print "After join : $single \n";


#splice()
@info = (10,20,30,40,50,60) ;
splice(@info,0,2,(100,200));   # will replace with 0th index with 100 and 1st index 			       #with 200
print "After replacing : @info \n";





