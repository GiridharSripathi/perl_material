## module for connecting to database ( common module for all the databases )
use DBI;
use strict;
use warnings;
 
my $userid = "root";

my $password = "giridhar";

#DATA SOURCE NAME
my $dsn = "DBI:mysql:host=localhost:port=3306";
 
# connecting to database server
my $dbh = DBI->connect($dsn, $userid, $password ) or die $DBI::errstr;
print "Step1 : database connection successful\n";

# define the query
my $sth = $dbh->prepare("create database nomuratest") or die("Unable to create database\n");


# execute the query
$sth->execute() or die $DBI::errstr;
print "Step2 : database created\n";
 
# disconnect from DB 

$sth->finish();
print "Step3 : disconnected from the DB engine\n";
 