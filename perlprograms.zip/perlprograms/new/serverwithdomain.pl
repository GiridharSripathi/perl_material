



@alist = ("unix","shell","oracle","java");

print "@alist \n";