

foreach $value ( 1..10)
{
	print $value , "\n";
}
###########################################
print "\n";
# $_ is called default variable
foreach $_ ( 1..10)
{
	print $_ , "\n";
}
###########################################

# $_ is called default variable
foreach ( 1..10)
{
	print $_ , "\n";
}
###########################################
foreach ( 1..10)
{
	print ;
}