
use DBI;
use strict;

my $driver = "mysql"; 
my $database = "emerson";
my $userid = "root";
my $password = "giridhar";
my $line;


#DATA SOURCE NAME

my $dsn = "dbi:mysql:$database:localhost:3306";



my $dbh = DBI->connect($dsn, $userid, $password ) or die $DBI::errstr;



my $query = "insert into empinfo values('sam',1003)";

my $sth = $dbh->prepare($query);

$sth->execute() or die $DBI::errstr;

$sth->finish();





