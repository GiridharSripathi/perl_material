use DBI;
use strict;
use warnings;

my $userid = "root";
my $sth ; 
my $password = "giridhar";
my $database = "emerson";
my $driver = 'mysql';
my $dsn = "DBI:$driver:database=$database:host=localhost:port=3306";
my $dbh = DBI->connect($dsn, $userid, $password ) or die $DBI::errstr;
print "Step1 : database connection successful\n";

open(READ,"<realestate.csv"); 
my $header = <READ> ;
while ( my $line = <READ> )
{
	chomp($line);
	print "$line\n";
	my ($street,$city,$zip,$state,$beds,$baths,$sft,$type,$saledate,$price,$latitude,$longitude) =
        split("," , $line) ;
        my $query = "INSERT INTO realestate values('$street','$city',$zip,'$state',$beds,$baths,$sft,'$type','$saledate',$price,'$latitude','$longitude');";
       $sth = $dbh->prepare($query); 
       $sth->execute() or die $DBI::errstr;
	print "Record inserted\n";
}
$sth->finish();






close(READ) ;



