use Excel::Writer::XLSX;                            
open ( READ, "realestate.csv");
my $workbook = Excel::Writer::XLSX->new( 'perl.xlsx' );    # Step 1
$worksheet = $workbook->add_worksheet(); 

$format = $workbook->add_format();
$format->set_bold();
$format->set_color( 'red' );
$format->set_align( 'center' );
           
$row = 0 ;
while ( $line = <READ> )
{	
	
	@output = split("," , $line );
	$len = scalar(@output);
	foreach $column ( 0 .. $len ) 
	{
	$worksheet->write( $row, $column, $output[$column], $format);
 	}
	$row = $row + 1;
}

$workbook->close();
close(READ);