

################# displaying all the environment variables ###############
#print %ENV ;


foreach $item ( keys %ENV )
{
	print "Key    :$item\n";
	print "Value  :$ENV{$item} \n\n";
}
