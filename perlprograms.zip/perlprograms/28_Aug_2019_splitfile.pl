
# a.b.txt
print 'Enter any filename :';
$file  = <STDIN> ;
@output  = split(/\./ , $file ) ;

print "File name : $output[0] \n" ;
print "Extension : $output[1] \n";