use strict;
use warnings;

use LWP::Simple;

my $url = 'http://samplecsvs.s3.amazonaws.com/Sacramentorealestatetransactions.csv';
my $file = 'test.csv';

getstore($url, $file);