# display file size

opendir(DIR , "."  ) or die("unable to open the directory : $! ");


while ( $file = readdir(DIR) )
{
	if (-f $file )
	{
		$size = -s $file ;
		print "File   : $file \n";
		print "Size   : $size bytes \n";
		print "--------------------\n";
	}
}

