
sub add
{
	print "@_\n";
	$count = $_[0] + $_[1] ;
	print "Output is $count \n";
}


add(1,2);