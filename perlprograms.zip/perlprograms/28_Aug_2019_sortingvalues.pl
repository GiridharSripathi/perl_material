
@elements = (10,111,45,5,6,65,543,56,342,89) ;
@sortedvalues = sort { $a <=> $b } @elements ;
print "After sorting : @sortedvalues \n";

# reverse order
@sortedvalues = sort { $b <=> $a } @elements ;
print "After sorting : @sortedvalues \n";


@numbers = (10,20,30,40,50);
$, =  ' ';
print reverse(@numbers) , "\n";

################## LEngth of the array ##################

#1st method
print "length of array  : " ,$#numbers + 1 ,"\n";

#2nd method
print "length of array  : " , scalar(@numbers)  , "\n";

#3rd method
$getlength = @numbers ;
print "length of array  : " ,$getlength ,"\n";



