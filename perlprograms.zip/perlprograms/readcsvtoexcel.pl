use Excel::Writer::XLSX;
use strict;
use warnings;

my $value ;
my $line ;
my $row;
my $workbook  = Excel::Writer::XLSX->new( 'realestate1.xlsx' );
my $worksheet = $workbook->add_worksheet();
my @data ;
$row = 0;
open(READ, "realestate.csv");
while ( $line = <READ> )
{
	chomp $line ;
	@data = split("," , $line);
	$worksheet->write( $row, 0, $data[0] );
	$worksheet->write( $row, 1, $data[1] );
	$worksheet->write( $row, 2, $data[2] );
	$worksheet->write( $row, 3, $data[3] );
	$worksheet->write( $row, 4, $data[4] );
	$worksheet->write( $row, 5, $data[5] );
	$worksheet->write( $row, 6, $data[6] );
	$worksheet->write( $row, 7, $data[7] );
	$worksheet->write( $row, 8, $data[8] );
	$worksheet->write( $row, 9, $data[9] );
	$worksheet->write( $row, 10, $data[10] );
	$worksheet->write( $row, 11, $data[11] );
	$row = $row + 1 ;
}
close(READ);
$workbook->close();