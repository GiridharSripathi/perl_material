#creating reference
@arr1 = (10,20);
@arr2 = (30,40);

print "@arr1\n";
print "@arr1\n";
# creating reference
$refarr1 = \@arr1;
$refarr2 = \@arr2 ;

print "first reference : $refarr1\n";
print "second reference : $refarr2\n";

#derefererce
print "First array : @$refarr1 \n";
print "Secondarray : @$refarr2 \n";