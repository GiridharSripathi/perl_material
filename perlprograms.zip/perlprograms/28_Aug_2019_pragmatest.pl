use warnings ;
use strict ;

my @information ;

print "@information" ;

print 'hello';
