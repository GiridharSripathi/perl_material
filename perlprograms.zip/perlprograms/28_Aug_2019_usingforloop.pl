# using for loop
for ( $i = 1 ; $i <=10 ; $i++ )
{
	print "$i\n";
}

print "------------------------------------\n";

@list = (11..100);
print "@list\n";

# using foreach

foreach $value ( @list)
{
	print "$value\n";
}

print "------------------------------------\n";

# displaying all alphabets
@alphas = ( aaa..zzz);
foreach $alpha ( @alphas )
{
	print "$alpha\n";
}