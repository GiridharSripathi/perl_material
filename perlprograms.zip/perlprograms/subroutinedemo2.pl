
# displaying line by line
# @_ contains 2 values( references)
sub add
{
	#dereferencing the values 
	print "@{$_[0]} \n";
	print "@{$_[1]} \n";
}	

@arr1 = (1..1000);
@arr2 = (1001..2000);

$refarr1 = \@arr1 ;
$refarr2 = \@arr2 ;



# references are passed
add($refarr1, $refarr2);

