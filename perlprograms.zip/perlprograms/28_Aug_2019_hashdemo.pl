%book     = ("chap1" , 10 , "chap2", 20 , "chap3", 30 ) ;
# $, is an predefined variable
$, = " ";
print %book;
print "\n";
# accessing individual key
print $book{'chap1'} , "\n";
print $book{'chap2'} , "\n";
print $book{'chap3'} , "\n";
print $book{'chap4'} , "\n";

%book     = ("chap1" , 10 , "chap2", 20 , "chap3", 30 , "chap1",10000 ) ;
print %book;
print "\n";


