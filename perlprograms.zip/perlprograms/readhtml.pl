

use HTML::TreeBuilder;

$tree = HTML::TreeBuilder->new;
$tree->parse_file('test.html');

@divs = $tree->find('div');

print "@divs";
$tree->delete;