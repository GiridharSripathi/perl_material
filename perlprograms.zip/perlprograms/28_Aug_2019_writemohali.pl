

open( READ, "<realestate.csv"); 
$header = <READ> ;
open(WRITE , ">mohaliinfo.csv");
print WRITE "$header";
%unique = ();
while ( $line = <READ> )
{
	chomp $line ;
	# convert scalar to array
	@output = split("," , $line) ;
	if ( $output[1] eq "SACRAMENTO" )
	{
		
		$output[1] = "MOHALI";
		#converting array to scalar
		$newline = join(",",@output) ;
		print "$newline\n";
		print WRITE "$newline\n";
	}
	else
	{
	       print WRITE "$line\n";
	}

}

close(READ) ;
close(WRITE);

