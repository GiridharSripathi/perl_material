use strict;
use warnings;

my @output ;

open(READ, "<realestate.csv") || die("Unable to open the file : $!");

while ( my $line = <READ> )
{
	chomp $line ;	
	#print $line ;
	@output = split("," , $line) ;
	print $output[0] ,"\n";
	print $output[1] ,"\n";
	print " --------------------------------\n";



}

close(READ);