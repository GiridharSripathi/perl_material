
# COMMAND LINE ARGUMENTS: passing the arguments from outside the program 

# @ARGV is a pre-defined which stores passed from the command line

print "@ARGV\n";

print "total no. of command line arguments " , scalar(@ARGV) , "\n";