use strict;
use warnings;

use LWP::Simple;

my $url = 'http://samplecsvs.s3.amazonaws.com/Sacramentorealestatetransactions.csv';

my @data = split('/',$url) ;

my $filename = $data[-1];

getstore($url, "C:\\Users\\Admin\\Desktop\\$filename");