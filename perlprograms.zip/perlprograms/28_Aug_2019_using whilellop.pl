# using while loop


@list = (1..10);
$count = 0;
while ( $count <= 10 )
{
	print "$list[$count]\n";
	$count = $count + 1;
}	


