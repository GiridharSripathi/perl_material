

open(READ, "languages111111.txt") or die("unable to open the file ") ;

while ( $line = <READ> )
{
	print $line;
}

close(READ);

print "After file handling\n";