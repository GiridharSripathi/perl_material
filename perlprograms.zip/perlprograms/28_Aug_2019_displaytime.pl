

# scalar context
# display localtime()
$timestamp = localtime();
print "Current timestamp : $timestamp \n";


# display gmtime()

$timestamp = gmtime();
print "Current timestamp : $timestamp \n";

# displaying epoch time 
print "Epoch time : ",time();


