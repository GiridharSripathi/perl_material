open(WRITE , ">customers.txt");

open(WRITE < "<abc.txt");

print WRITE "hello perl\n";




close(WRITE);