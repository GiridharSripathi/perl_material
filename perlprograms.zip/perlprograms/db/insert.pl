#!/usr/bin/perl

use DBI;
use strict;

my $driver = "mysql"; 
my $database = "ibm";
my $dsn = "DBI:$driver:database=$database";
my $userid = "root";
my $password = "password";

#DATA SOURCE NAME
$dsn = "dbi:mysql:$database:localhost:3307";

my $dbh = DBI->connect($dsn, $userid, $password ) or die $DBI::errstr;
my $query = "INSERT INTO empinfo (empname,empid) values('rahul', 'poul', 1005)";
my $sth = $dbh->prepare($query);
print "record inseted....\n";
$sth->execute() or die $DBI::errstr;
$sth->finish();
#$dbh->commit or die $DBI::errstr;