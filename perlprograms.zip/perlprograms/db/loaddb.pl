#!/usr/bin/perl


use DBI;

use strict;


my $driver = "mysql"; 

my $database = "ibm";

my $dsn = "DBI:$driver:database=$database";

my $userid = "root";

my $password = "password";


#DATA SOURCE NAME

$dsn = "dbi:mysql:$database:localhost:3307";


my $dbh = DBI->connect($dsn, $userid, $password ) or die $DBI::errstr;


open(READ,"<departments.csv");

while ( my $line = <READ> )

{
	
	chomp($line);
	
	my ($id,$first,$last,$depatment,$status) = split("," , $line);

	my $query = "INSERT INTO departments(StaffID,Forename,Surname,Department,Status) values($id,\"$first\",\"$last\",\"$depatment\",\"$status\")";

       
       my $sth = $dbh->prepare($query);
$sth->execute() or die $DBI::errstr;
       $sth->finish();


}
