#!/usr/bin/perl

use DBI;
use strict;

my $driver = "mysql"; 
my $database = "nomura";
my $userid = "root";
my $password = "giridhar";


#DATA SOURCE NAME

my $dsn = "dbi:mysql:$database:localhost:3306";



my $dbh = DBI->connect($dsn, $userid, $password ) or die $DBI::errstr;



my $sth = $dbh->prepare("select * from realestate");


$sth->execute() or die $DBI::errstr;



while (my @row = $sth->fetchrow_array()) 
{
	
	print "@row\n";

}


$sth->finish();





