!/usr/bin/perl

use DBI;
use strict;

my $driver = "mysql"; 
my $database = "ibm";
my $dsn = "DBI:$driver:database=$database";
my $userid = "root";
my $password = "password";

#DATA SOURCE NAME
$dsn = "dbi:mysql:$database:localhost:3307";

my $dbh = DBI->connect($dsn, $userid, $password ) or die $DBI::errstr;

my $name = "ram";
my $sth = $dbh->prepare("DELETE FROM empname  WHERE empname = ?");
$sth->execute( $name ) or die $DBI::errstr;
print "Number of rows deleted :" + $sth->rows;
$sth->finish();
$dbh->commit or die $DBI::errstr;