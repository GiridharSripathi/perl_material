## module for connecting to database ( common module for all the databases )
use DBI;
use strict;
use warnings;
  
# customize your userid accordingly 
my $userid = "root";
 
my $sth ; 
# customize your password
my $password = "giridhar";
 
# customize your database accordingly
my $database = "emerson";
 
#DATA SOURCE NAME
my $dsn = "DBI:mysql:database=$database:host=localhost:port=3306";
 
# connecting to database server
my $dbh = DBI->connect($dsn, $userid, $password ) or die $DBI::errstr;
print "Step1 : database connection successful\n";
 
# fields to be inserted

open(READ,"<realestate.csv"); 
my $header = <READ> ;
while ( my $line = <READ> )
{
	chomp($line);
	print "$line\n";
	my ($street,$city,$zip,$state,$beds,$baths,$sft,$type,$saledate,$price,$latitude,$longitude) =
        split("," , $line) ;

        my $query = "INSERT INTO realestate values('$street','$city',$zip,'$state',$beds,$baths,$sft,'$type','$saledate',$price,'$latitude','$longitude');";
 
       $sth = $dbh->prepare($query);
 
 
 
       $sth->execute() or die $DBI::errstr;
	print "Record inserted\n";
}
$sth->finish();
print "Step3 : disconnecting from database \n";
#$dbh->commit or die $DBI::errstr;
close(READ) ;



#my $query = "INSERT INTO realestate values('$street','$city','$zip','$state','$beds','$baths','$sft','$type','$saledate','$price','$latitude','$longitude');";