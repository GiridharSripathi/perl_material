use Net::Ping;
$p = Net::Ping->new("tcp");
$p->port_number("80");
open(READ, "ips.txt");

while ( $host = <READ> )
{
	chomp $host;
	if( $p->ping($host) )
	{
        	print "Host ".$host." is alive\n";
	}
	else
	{
        	print "Host ".$host." is dead\n";
	}
}


close(READ);